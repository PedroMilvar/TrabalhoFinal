<?php
session_start();
require "database.php";
$pdo = mysqlConnect();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $idCurso = $_POST['curso'];

   
    $sql = <<<SQL
            DELETE FROM CURSOS WHERE idCurso = ?
            SQL;
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([$idCurso]);
        
        header("Location: /privada/professor/index.php");
        exit();
    } catch (Exception $e) {
        exit('Falha ao excluir o curso: ' . $e->getMessage());
    }
}
?>
