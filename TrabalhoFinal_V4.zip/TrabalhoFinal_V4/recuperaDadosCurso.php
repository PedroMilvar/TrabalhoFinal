<?php
session_start();
require 'database.php';
$pdo = mysqlConnect();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idCurso = $_POST["idCurso"] ?? "";

    $sql = "SELECT * FROM CURSOS WHERE idCurso = ?";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idCurso]);
        $curso = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->close;
        echo json_encode($curso);
    } catch (Exception $e) {
        
        exit('Falha ao obter dados do curso: ' . $e->getMessage());
    }
    finally {
        closeConnection($pdo);
    }
    
}
?>
