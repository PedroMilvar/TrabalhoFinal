<?php
session_start();

// Verifica se a variável de sessão 'usuario' está definida
if (!isset($_SESSION['usuario'])) {
    header("location: /privada/login/credenciaisAluno.html");
    die("Acesso negado, voce precisa estar logado");
    exit();
}

// Se o usuário está autenticado, você pode acessar a variável de sessão 'usuario'
$usuario = $_SESSION['usuario'];

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Página Inicial</title>
  <link href="../../bootstrap/css/bootstrap.min.css" rel="stylesheet" />
  <script src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../../style.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
  <script type="text/javascript" src="script.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<style type="text/css">
  .navbar-nav .last-item {
      margin-left: auto !important;
      font-weight: bold;
  }

  .welcome {
    font-weight: bold;
    font-size: 18px;
    color: #333; /* Cor desejada */
}
</style>

<body>
  <header>
    <div>
      <a href="/index.html">
        <img src="/img/logo.png" alt="Logo" height="60" width="250">
      </a>
    </div>
    <nav class="navbar navbar-expand-lg navbar-light cor_menu">
      <div class="container">
        <a class="navbar-brand" href="index.php">Página Inicial</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="favoritos.php">Favoritos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="busca.php">Pesquisar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="perfil.php">Perfil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ranking.php">Ranking</a>
            </li>
            <li class="nav-item last-item">
              <a class="nav-link" href="logout.php"><?php echo $_SESSION['usuario']; ?> (Sair)</a>
            </li>
            <li class="nav-item">
                <img src="../../../imagemPerfilAluno.php" alt="Imagem do Usuário" width = "50" height = "40" class="rounded mr-2">
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
        
  <main class="container mt-5">

    <p class="welcome">Bem vindo, <?php echo $_SESSION['usuario']; ?></p>

    <h2 class="mb-4">Cursos Disponíveis</h2>

    <div class="row" id="cursos-container">
    
</div>

<div id="cursos-container"></div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        
        $.ajax({
            url: '/../../listarCursos.php',
            method: 'GET',
            success: function (data) {
                
                $('#cursos-container').html(data);
            },
            error: function (xhr, status, error) {
                console.error('Erro ao carregar cursos:', status, error);
            }
        });
    });
</script>
  </main>

    <script>
      const curso1Like = document.getElementById("curso1-like");
      const curso2Like = document.getElementById("curso2-like");
      const curso3Like = document.getElementById("curso3-like");
      const curso4Like = document.getElementById("curso4-like");
      const curso5Like = document.getElementById("curso5-like");

      curso1Like.addEventListener("click", function () {
        toggleLike(this);
      });

      curso2Like.addEventListener("click", function () {
        toggleLike(this);
      });

      curso3Like.addEventListener("click", function () {
        toggleLike(this);
      });

      curso4Like.addEventListener("click", function () {
        toggleLike(this);
      });

      curso5Like.addEventListener("click", function () {
        toggleLike(this);
      });

      function toggleLike(button) {
        if (button.classList.contains("far")) {
          button.classList.remove("far");
          button.classList.add("fas");
        } else {
          button.classList.remove("fas");
          button.classList.add("far");
        }
      }
    </script>


  <footer class="bg-black text-white text-center">
    <p>© Copyright 2023. Todos os direitos reservados.</p>
  </footer>
</body>
</html>