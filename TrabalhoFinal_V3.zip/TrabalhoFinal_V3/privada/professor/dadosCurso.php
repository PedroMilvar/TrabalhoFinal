<?php
session_start();
require __DIR__ . '/../../database.php';
$pdo = mysqlConnect(); 

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $usuario = $_SESSION['usuario'];

    $sql = "SELECT idCurso, tituloCurso FROM CURSOS WHERE email = ?";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$usuario]);
        $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        exit('Falha ao obter cursos: ' . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alterar dados do curso</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../style.css" />

</head>

<style type="text/css">
  .navbar-nav .last-item {
      margin-left: auto !important;
      font-weight: bold;
  }

  .welcome {
    font-weight: bold;
    font-size: 18px;
    color: #333; /* Cor desejada */
}
</style>


<body>

  <header>
    <div>
      <a href="/index.html">
        <img src="/img/logo.png" alt="Logo" height="60" width="250">
      </a>
    </div>
    <nav class="navbar navbar-expand-lg navbar-light cor_menu">
      <div class="container">
        <a class="navbar-brand" href="index.php">Página Inicial</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="pesquisar.php">Pesquisar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="cadastro.php">Cadastrar Curso</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="dadosCurso.php">Alterar cursos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="perfil.php">Perfil</a>
            </li>
            <li class="nav-item last-item">
              <a class="nav-link" href="logout.php"><?php echo $_SESSION['usuario']; ?> (Sair)</a>
            </li>
            <li class="nav-item">
                <img src="../../../imagemPerfilProfessor.php" alt="Imagem do Usuário" width = "50" height = "40" class="rounded mr-2">
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

    <main class="container mt-5">
        <h2 class="mb-5">Altere os dados do curso</h2>
                
        <form action="../../../atualizarCurso.php" method="POST">
        <div class="form-group mb-3">
        <label for="selectCurso">Escolha o curso:</label>
        <select id="selectCurso" name="curso" onchange="carregarDadosCurso()">
            <?php foreach ($cursos as $curso): ?>
                <option value="<?php echo $curso['idCurso']; ?>"><?php echo $curso['tituloCurso']; ?></option>
            <?php endforeach; ?>
        </select>
        </div>

            <div class="form-group mb-5">
                <label for="titulo" class="custom-label">Altere o Título do Curso:</label>
                <input type="text" class="form-control" id="titulo" name="titulo" required>
            </div>

            <div class="form-group mb-5">
                <label for="professor" class="custom-label">Sobre o professor:</label>
                <textarea class="form-control" id="professor" name="professor" rows="4" required></textarea>
            </div>

            <div class="form-group mb-5">
                <label for="descricao" class="custom-label">Descrição do Curso:</label>
                <textarea class="form-control" id="descricao" name="descricao" rows="4" required></textarea>
            </div>

            <div class="form-group mb-5">
                <label for="cargaHoraria" class="custom-label">Carga Horária:</label>
                <input type="number" class="form-control" id="cargaHoraria" name="cargaHoraria" required>
            </div>

            <div class="form-group mb-5">
                <label for="formato" class="custom-label">Formato:</label>
                <select class="form-control" id="formato" name="formato" required>
                    <option value="presencial">Presencial</option>
                    <option value="online">Online</option>
                </select>
            </div>

            <div class="form-group mb-5">
                <label for="ementa" class="custom-label">Ementa:</label>
                <textarea class="form-control" id="ementa" name="ementa" rows="4" required></textarea>
            </div>

            <div class="form-group mb-5">
                <label for="duracao" class="custom-label">Duração:</label>
                <input type="number" class="form-control" id="duracao" name="duracao" required>
            </div>

            <div class="form-group mb-5">
                <label for="localizacao" class="custom-label">Localização (para cursos presenciais):</label>
                <input type="text" class="form-control" id="localizacao" name="localizacao">
            </div>

            <div class="form-group mb-5">
                <label for="localizacao" class="custom-label">Link para página do professor:</label>
                <input type="text" class="form-control" id="link" name="link" required>
            </div>

            <div class="form-group mb-5">
                <label for="cargaHoraria" class="custom-label">Número de Aulas ou Módulos:</label>
                <input type="number" class="form-control" id="modulo" name="modulo" required>
            </div>

            <div class="form-group mb-5">
                <label for="localizacao" class="custom-label">Idioma do Curso</label>
                <input type="text" class="form-control" id="idioma" name="idioma" required>
            </div>
            <button type="submit" class="btn btn-primary mb-5">Alterar Dados do Curso</button>
        </form>

         <form action="/../../deletarCurso.php" method="POST">
        <select id="curso" name="curso" onchange="pegarID()">
            <?php foreach ($cursos as $curso): ?>
                <option value="<?php echo $curso['idCurso']; ?>"><?php echo $curso['tituloCurso']; ?></option>
            <?php endforeach; ?>
        </select>

        <input type="hidden" id="idCurso" name="idCurso" value="">

        <button type="submit" class="btn btn-danger" onclick="return confirmarExclusaoCurso()">Deletar Curso</button>
    </form>


    </main>

    <footer class="bg-black text-white text-center">
        <p>© Copyright 2023. Todos os direitos reservados.</p>
    </footer>

  <script>
        function pegarID() {
        var selectCurso = document.getElementById('curso');
        var cursoIdHidden = document.getElementById('idCurso');
    
        idCurso.value = curso.value;
    }

    function confirmarExclusaoCurso() {
    return confirm('Tem certeza que deseja excluir o curso?');
    }

    </script>

    <script>
    function carregarDadosCurso() {
    var selectCurso = document.getElementById('selectCurso');
    var idCurso = selectCurso.value;

    $.ajax({
        url: '/../../recuperaDadosCurso.php',
        method: 'POST',
        data: { idCurso: idCurso },
        success: function (data) {
            var curso = JSON.parse(data);

            document.getElementById('titulo').value = curso.tituloCurso;
            document.getElementById('professor').value = curso.sobreProfessor;
            document.getElementById('descricao').value = curso.descricaoCurso;
            document.getElementById('cargaHoraria').value = curso.cargaHoraria;
            document.getElementById('formato').value = curso.formato;
            document.getElementById('ementa').value = curso.ementa;
            document.getElementById('duracao').value = curso.duracao;
            document.getElementById('localizacao').value = curso.localizacao;
            document.getElementById('link').value = curso.link;
            document.getElementById('modulo').value = curso.modulos;
            document.getElementById('idioma').value = curso.idioma;
        },
        error: function (xhr, status, error) {
            console.error('Erro ao carregar dados do curso:', status, error);
        }
    });
}


$(document).ready(function () {
    carregarDadosCurso();
});
</script>


</body>

</html>