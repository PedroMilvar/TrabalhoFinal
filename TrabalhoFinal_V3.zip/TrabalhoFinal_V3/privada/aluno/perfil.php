 <?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../../database.php';
$pdo = mysqlConnect(); 

if (!isset($_SESSION['usuario'])) {
    // Se não estiver autenticado, redireciona para a página de login
    header("Location: /privada/login.php");
    exit();

    } 

$usuario = $_SESSION['usuario'];

$sql = <<<SQL
        SELECT * FROM ALUNO WHERE email = ?
        SQL;
$stmt = $pdo->prepare($sql);
$stmt->execute([$usuario]);
$dadosAluno = $stmt->fetch(PDO::FETCH_ASSOC);

// Verifica se encontrou o aluno
if (!$dadosAluno) 
    exit('Aluno não encontrado.'); 

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Perfil - Aluno</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.min.js"></script>
  <link rel="stylesheet" type="text/css" href="../../style.css" />
</head>

<style type="text/css">
  .navbar-nav .last-item {
      margin-left: auto !important;
      font-weight: bold;
  }

  .welcome {
    font-weight: bold;
    font-size: 18px;
    color: #333; /* Cor desejada */
}
</style>

<body>

  <header>
    <div>
      <a href="/index.html">
        <img src="/img/logo.png" alt="Logo" height="60" width="250">
      </a>
    </div>
    <nav class="navbar navbar-expand-lg navbar-light cor_menu">
      <div class="container">
        <a class="navbar-brand" href="index.php">Página Inicial</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="favoritos.php">Favoritos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="busca.php">Pesquisar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="perfil.php">Perfil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ranking.php">Ranking</a>
            </li>
            <li class="nav-item last-item">
              <a class="nav-link" href="logout.php"><?php echo $_SESSION['usuario']; ?> (Sair)</a>
            </li>
            <li class="nav-item">
                <img src="../../../imagemPerfilAluno.php" alt="Imagem do Usuário" width = "50" height = "40" class="rounded mr-2">
            </li>
          </ul>
        </div>
      </div>
    </nav>


  </header>

  <main class="container mt-5">
    <p>Bem vindo, <?php echo $_SESSION['usuario']; ?></p>
    <h2 class="mb-5">Altere os seus dados de perfil</h2>

    <form action="../../../atualizarCadastroAluno.php" method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="nome" class="form-label">Nome completo:</label>
        <input type="text" name="nome" id="nome" class="form-control" maxlength="50" value="<?php echo $dadosAluno["nome"]; ?>">
      </div>

      <div class="mb-3 form-group">
        <label for="data" class="form-label">Data de nascimento:</label>
        <input type="date" name="dataNascimento" id="data" class="form-control" value="<?php echo $dadosAluno["dataNascimento"]; ?>">
      </div>

      <div class="mb-3 form-group">
        <label for="telefone" class="form-label">Telefone:</label>
        <input type="tel" name="telefone" id="telefone" class="form-control" value="<?php echo $dadosAluno["telefone"]; ?>">
      </div>

      <div class="mb-3 form-group">
        <label for="cpf" class="form-label">CPF:</label>
        <input type="text" name="cpf" id="cpf" class="form-control" value="<?php echo $dadosAluno["cpf"]; ?>">
      </div>

        <p class="mb-4" style="font-weight: bold; color: #333;">Endereço:</p>
        <div class="input-group mb-4">
            <span class="input-group-text">Estado</span>
            <select class="form-select" aria-label="Selecione um estado" name="estado" id="estado" value="<?php echo $dadosAluno["estado"]; ?>">
                <option selected>Estado</option>
            </select>
            <span class="input-group-text">Cidade</span>
            <input type="text" name="cidade" id="cidade" class="form-control"   value="<?php echo $dadosAluno["cidade"]; ?>">
        </div>

        <script>
            $(document).ready(function () {
                $.ajax({
                    url: 'estados.php',
                    dataType: 'json',
                    success: function (data) {
                        var selectEstado = $('#estado');

                        // Obtém o valor do cookie (se existir)
                        var estadoEscolhido = getCookie("estado_escolhido");

                        $.each(data, function (sigla, estado) {
                            var option = $('<option>').val(sigla).text(estado);

                            // Define a propriedade selected se a sigla corresponder à escolha do usuário
                            if (sigla === estadoEscolhido) {
                                option.prop('selected', true);
                            }

                            selectEstado.append(option);
                        });
                    },
                    error: function () {
                        alert('Erro ao carregar estados.');
                    }
                });
            });

            // Função para obter o valor de um cookie
            function getCookie(name) {
                var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
                if (match) return match[2];
            }

            $(document).ready(function () {
                // Aplica a máscara de CPF ao campo
                $('#cpf').inputmask('999.999.999-99');
            })
        </script>

        
      <div class="form-group mb-3">
        <label for="imagemPerfilAluno" class="custom-label">Alterar foto de perfil:</label>
        <div class="custom-file">
          <input type="file" class="custom-file-input" id="imagemPerfilAluno" name="imagem" accept="image/*">
          <label class="custom-file-label" for="imagemCapa">Escolher arquivo</label>
        </div>
      </div>

      <div class="mb-3 form-group">
        <label for="exampleFormControlTextarea1" class="form-label">Biografia:</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="10" name="biografia" ><?php echo $dadosAluno['biografia']; ?></textarea>
      </div>
      <input type="hidden" name="email" value="<?php echo $_SESSION['usuario']; ?>">
        <div class="form-group mt-3">
            <input type="submit" class="btn btn-primary" id="alterarDadosAluno" value="Alterar Dados">
        </div>
      </form>

    <form action="../../../deletarContaAluno.php" method="POST" class="ml-2 ml-md-1">
        <button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja excluir sua conta?')">Excluir Conta</button>
    </form>

  </main>

  <footer class="bg-black text-white text-center">
    <p>© Copyright 2023. Todos os direitos reservados.</p>
  </footer>

</body>

</html>