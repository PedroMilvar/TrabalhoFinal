<?php
session_start();
require "database.php";
$pdo = mysqlConnect();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $usuario = $_SESSION['usuario'];

    
    $sql = <<<SQL
           DELETE FROM ALUNO WHERE email = ?
           SQL;
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute([$usuario])) {
      
        session_unset();
        session_destroy();

        
        header("Location: /privada/login/credenciaisAluno.html");
        exit();
    } else {
        exit('Falha ao excluir a conta.');
    }
   

}
?>