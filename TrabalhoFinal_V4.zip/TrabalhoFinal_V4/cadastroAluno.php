<?php

require "database.php";
$pdo = mysqlConnect();

$email = $_POST["email"] ?? "";
$senha = $_POST["senha"] ?? "";


$verificarEmail = <<<SQL
  SELECT COUNT(*) as count FROM ALUNO WHERE email = ?
SQL;

$stmtVerificar = $pdo->prepare($verificarEmail);
$stmtVerificar->execute([$email]);
$resultadoVerificar = $stmtVerificar->fetch(PDO::FETCH_ASSOC);

if ($resultadoVerificar['count'] > 0) {
    
    exit('E-mail já cadastrado. Faça login ou escolha outro e-mail.');
}

$hashsenha = password_hash($senha, PASSWORD_DEFAULT);

try {
    $sql = <<<SQL
    INSERT INTO ALUNO (email, senha)
    VALUES (?, ?)
SQL;

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email, $hashsenha]);

    header("location: /privada/login/credenciaisAluno.html");
    exit();
} catch (Exception $e) {
    if ($e->errorInfo[1] === 1062)
        exit('Dados duplicados: ' . $e->getMessage());
    else
        exit('Falha ao cadastrar os dados: ' . $e->getMessage());
}
finally {
    // Fecha a conexão PDO explicitamente
    closeConnection($pdo);
}

