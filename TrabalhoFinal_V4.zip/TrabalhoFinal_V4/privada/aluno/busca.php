<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../../database.php';
$pdo = mysqlConnect(); 

if (!isset($_SESSION['usuario'])) {
    header("Location: /privada/login.php");
    exit();
}

$usuario = $_SESSION['usuario'];

// Consulta SQL para obter dados do curso específico
$sql = "SELECT * FROM CURSOS WHERE idCurso = ?";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(1, $usuario, PDO::PARAM_INT);
$stmt->execute();
$dadosCurso = $stmt->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Pesquisar</title>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="../../style.css" />
  <style type="text/css">
    .navbar-nav .last-item {
        margin-left: auto !important;
        font-weight: bold;
    }
    .welcome {
      font-weight: bold;
      font-size: 18px;
      color: #333;
    }
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
  <script type="text/javascript" src="script.js"></script>
</head>

<body>
  <header>
    <div>
      <a href="/index.html">
        <img src="/img/logo.png" alt="Logo" height="60" width="250">
      </a>
    </div>
    <nav class="navbar navbar-expand-lg navbar-light cor_menu">
      <div class="container">
        <a class="navbar-brand" href="index.php">Página Inicial</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="favoritos.php">Favoritos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="busca.php">Pesquisar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="perfil.php">Perfil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ranking.php">Ranking</a>
            </li>
            <li class="nav-item last-item">
              <a class="nav-link" href="logout.php"><?php echo $_SESSION['usuario']; ?> (Sair)</a>
            </li>
            <li class="nav-item">
                <img src="../../../imagemPerfilAluno.php" alt="Imagem do Usuário" width = "50" height = "40" class="rounded mr-2">
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <main class="container mt-5">
        
    <h2 class="mb-4">Cursos Disponíveis</h2>

    <?php
    $sql = "SELECT idCurso, tituloCurso, sobreProfessor, descricaoCurso, cargaHoraria, formato, ementa, duracao FROM CURSOS";
    $result = $pdo->query($sql); 

    echo "<table id='tabela-cursos' class='table table-striped table-bordered'>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>idCurso</th>";
    echo "<th>tituloCurso</th>";
    echo "<th>sobreProfessor</th>";
    echo "<th>descricaoCurso</th>";
    echo "<th>cargaHoraria</th>";
    echo "<th>formato</th>";
    echo "<th>ementa</th>";
    echo "<th>duracao</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $row["idCurso"] . "</td>";
        echo "<td>" . $row["tituloCurso"] . "</td>";
        echo "<td>" . $row["sobreProfessor"] . "</td>";
        echo "<td>" . $row["descricaoCurso"] . "</td>";
        echo "<td>" . $row["cargaHoraria"] . "</td>";
        echo "<td>" . $row["formato"] . "</td>";
        echo "<td>" . $row["ementa"] . "</td>";
        echo "<td>" . $row["duracao"] . "</td>";
        echo "</tr>";
    }

    echo "</tbody>";
    echo "</table>";

    $pdo = null;
    
    ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function () {
            $('#tabela-cursos').DataTable({
                "language": {
                    "url": "https://cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Portuguese-Brasil.json"
                },
                searching: true,
                paging: true,
                ordering: true,
                processing: true,
                dom: 'Bfrtip',
                enable:false,
            });

            $('<button type="button" class="btn btn-primary mx-auto d-block">Limpar Tabela</button>').appendTo('body').on('click', function () {
                $('#tabela-cursos').DataTable().clear().draw();
            });

        });

    </script>
    <script type="text/javascript" src="script.js"></script>

  </main>

  <footer class="mt-5 bg-black text-white text-center">
    <p>© Copyright 2023. Todos os direitos reservados.</p>
  </footer>

</body>

</html>