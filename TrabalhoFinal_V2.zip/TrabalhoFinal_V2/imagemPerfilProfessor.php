<?php
session_start();
require "database.php";
$pdo = mysqlConnect();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $usuario = $_SESSION['usuario'];

    $sql = "SELECT imagem FROM PROFESSOR WHERE email = ?";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(1, $usuario, PDO::PARAM_STR);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row && $row['imagem']) {
            header('Content-Type: image/jpg'); 
            echo $row['imagem'];
            exit();
        } else {
            
            $imagemPadrao = file_get_contents("padrao.jpg");
            header('Content-Type: image/jpg');
            echo $imagemPadrao;
            exit();
        }
    } catch (Exception $e) {
        exit('Falha ao recuperar a imagem: ' . $e->getMessage());
    }
}
?>
