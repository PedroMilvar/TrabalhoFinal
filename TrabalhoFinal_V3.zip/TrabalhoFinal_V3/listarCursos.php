<?php
session_start();
require "database.php";
$pdo = mysqlConnect();

// Consulta para obter todos os cursos
$sql = "SELECT * FROM CURSOS";
$stmt = $pdo->query($sql);
$cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

 
?>

<?php foreach ($cursos as $curso): ?>
    <div class="col-md-4 mb-4">
        <div class="card">
            <div class="card-body" style="max-height: 300px; overflow-y: auto;">
                <h4 class="card-title"><?php echo $curso['tituloCurso']; ?></h4>
                <p class="card-text"><?php echo $curso['descricaoCurso']; ?></p>
                <p class="card-text"><b>Carga Horária:</b> <?php echo $curso['cargaHoraria']; ?> horas</p>
                <p class="card-text"><b>Formato:</b> <?php echo $curso['formato']; ?></p>
                <p class="card-text"><b>Ementa:</b> <?php echo $curso['ementa']; ?></p>
                <button class="btn btn-link like-button" style="text-decoration: none;">
                    <i class="far fa-heart"></i> Favoritar
                </button>
            </div>
        </div>
    </div>
<?php endforeach; ?>



