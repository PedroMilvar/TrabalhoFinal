<?php
session_start();
require "database.php";
$pdo = mysqlConnect();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $idCurso = isset($_POST["curso"]) ? $_POST["curso"] : "";
    
   
    $titulo = $_POST["titulo"] ?? "";
    $professor = $_POST["professor"] ?? "";
    $descricao = $_POST["descricao"] ?? "";
    $cargaHoraria = $_POST["cargaHoraria"] ?? "";
    $formato = $_POST["formato"] ?? "";
    $ementa = $_POST["ementa"] ?? "";
    $duracao = $_POST["duracao"] ?? "";
    $localizacao = $_POST["localizacao"] ?? "";
    $link = $_POST["link"] ?? "";
    $modulo = $_POST["modulo"] ?? "";
    $idioma = $_POST["idioma"] ?? "";

    
    $sql = <<<SQL
        UPDATE CURSOS 
        SET 
            tituloCurso = ?, 
            sobreProfessor = ?, 
            descricaoCurso = ?, 
            cargaHoraria = ?, 
            formato = ?, 
            ementa = ?, 
            duracao = ?, 
            localizacao = ?, 
            link = ?, 
            modulos = ?, 
            idioma = ? 
        WHERE 
            idCurso = ?
SQL;

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$titulo, $professor, $descricao, $cargaHoraria, $formato, $ementa, $duracao, $localizacao, $link, $modulo, $idioma, $idCurso]);
        $stmt->close;
        header("Location: /privada/professor/index.php");
        exit();
    } catch (Exception $e) {
        exit('Falha ao atualizar o curso: ' . $e->getMessage());
    }

    finally {
    // Fecha a conexão PDO explicitamente
    closeConnection($pdo);
}
}
?>
