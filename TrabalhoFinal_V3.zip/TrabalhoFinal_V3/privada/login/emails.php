<?php
// Substitua as configurações do banco de dados conforme necessário
$dsn = 'mysql:host=seu_host;dbname=sua_base_de_dados';
$username = 'seu_usuario';
$password = 'sua_senha';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta SQL para obter os e-mails do banco de dados
    $sql = 'SELECT email FROM tabela_de_usuarios';
    $stmt = $pdo->query($sql);

    // Obtém os resultados da consulta
    $emailsRegistrados = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Retorna os resultados em formato JSON
    echo json_encode($emailsRegistrados);
} catch (PDOException $e) {
    // Em caso de erro na conexão ou consulta
    echo json_encode(['error' => 'Erro no banco de dados: ' . $e->getMessage()]);
}
?>
