<?php
session_start();
require "database.php";
$pdo = mysqlConnect();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario = $_SESSION['usuario'];
    $nome = $_POST["nome"] ?? "";
    $dataNascimento = $_POST["dataNascimento"] ?? "";
    $telefone = $_POST["telefone"] ?? "";
    $cpf = $_POST["cpf"] ?? "";
    $estado = $_POST["estado"] ?? "";
    $cidade = $_POST["cidade"] ?? "";
    $biografia = $_POST["biografia"] ?? "";

    $estadoEscolhido = $_POST["estado"];

    // Definir um cookie para armazenar a escolha do estado por algum tempo (por exemplo, 30 dias)
    setcookie("estado_escolhido", $estadoEscolhido, time() + (30 * 24 * 60 * 60), "/");

    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $imagem = file_get_contents($_FILES['imagem']['tmp_name']);
    } else {
        $imagem = null;
    }

    $sql = <<<SQL
        UPDATE ALUNO SET nome=?, dataNascimento=?, telefone=?, cpf=?, estado=?, cidade=?, imagem=?, biografia=? WHERE email=?
    SQL;

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(1, $nome, PDO::PARAM_STR);
        $stmt->bindParam(2, $dataNascimento, PDO::PARAM_STR);
        $stmt->bindParam(3, $telefone, PDO::PARAM_STR);
        $stmt->bindParam(4, $cpf, PDO::PARAM_STR);
        $stmt->bindParam(5, $estado, PDO::PARAM_STR);
        $stmt->bindParam(6, $cidade, PDO::PARAM_STR);
        $stmt->bindParam(7, $imagem, PDO::PARAM_LOB);
        $stmt->bindParam(8, $biografia, PDO::PARAM_STR);
        $stmt->bindParam(9, $usuario, PDO::PARAM_STR);

        if (!$stmt->execute()) {
            throw new Exception('Falha na atualização do aluno');
        }

        header("location: /privada/aluno/index.php");
        exit();
    } catch (Exception $e) {
        exit('Falha ao atualizar os dados: ' . $e->getMessage());
    }

    finally {
    // Fecha a conexão PDO explicitamente
    closeConnection($pdo);
}

    
}   
?>
